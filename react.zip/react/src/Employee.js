const Employee=[
    {
        id:"1",
        Name:"Ajay",
        Age:"23",
        DOB:"26-07-2001",
        salary:"300000",
        department:"Sales"
        
    }
]

export default Employee;